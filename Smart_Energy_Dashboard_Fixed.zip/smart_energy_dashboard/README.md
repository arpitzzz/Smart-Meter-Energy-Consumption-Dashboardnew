# Smart Energy Dashboard (VS Code)

A local Streamlit dashboard for energy consumption, load surveys, meter inventory, anomaly screening, data exploration and CSV management.

## Included demo data

The `data/` directory contains three **synthetic demonstration CSVs** so the app works immediately:
- `consumption_clean.csv` — dated readings for multiple meters
- `load_survey_clean.csv` — sample survey records
- `meters_clean.csv` — sample meter inventory/status

These are not real utility records. Replace them with your own data through **Data Management** or overwrite the CSVs after taking a backup.

## Quick start (Windows / PowerShell)

Open this folder in VS Code: `smart_energy_dashboard` (the folder that contains `app.py`). In the terminal run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Open `http://localhost:8501` if the browser does not open automatically.

If PowerShell blocks activation, run this in the current terminal and retry activation:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

Alternatively, double-click `run_dashboard.bat` to create the environment, install requirements and start the app.

## Data management

- CSVs are loaded from `data/`.
- The Data Management page lets you upload and replace/append CSV records, add a record, delete a record and download stored data.
- Changes are written back to local CSV files and remain after restarting the app.
- Expected dataset names are `consumption_clean.csv`, `load_survey_clean.csv`, `meters_clean.csv`.
- The consumption dataset should ideally include `date`, `meter_id`, and `consumption_kwh`; other columns are explored dynamically.

## Notes

- Anomaly Detection uses an interquartile-range (IQR) rule; a flagged record is not automatically a confirmed fault.
- This is a local prototype. It does not include user authentication or remote hosting.


## Bug-fix release

This version fixes the pandas date aggregation that caused `ValueError: Length mismatch` on the Home Dashboard and Consumption Analysis pages. Daily chart data is now grouped using an explicit `_plot_date` column, and the output columns are renamed safely. The bundled CSV demo datasets are retained.
