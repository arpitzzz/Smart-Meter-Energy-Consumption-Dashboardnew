from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data'
FILES={'consumption_clean.parquet':'consumption_clean.csv','load_survey_clean.parquet':'load_survey_clean.csv','meters_clean.parquet':'meters_clean.csv'}
for src_name,dst_name in FILES.items():
    src=ROOT/src_name; dst=DATA/dst_name
    if not src.exists(): print(f'SKIP: {src_name} not found'); continue
    if dst.exists():
        answer=input(f'{dst_name} already exists. Replace it? [y/N] ').strip().lower()
        if answer!='y': print('Kept existing CSV'); continue
    try:
        df=pd.read_parquet(src); df.to_csv(dst,index=False); print(f'Converted {src_name}: {len(df)} rows, {len(df.columns)} columns -> {dst}')
    except Exception as e: print(f'ERROR converting {src_name}: {e}')
