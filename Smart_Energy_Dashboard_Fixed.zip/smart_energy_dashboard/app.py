from pathlib import Path
import sys
import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
ROOT=Path(__file__).resolve().parent
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from utils.data_loader import DATASETS, load_all, save_dataset
from utils.analysis import numeric_columns, date_column, find_anomalies, filtered_frame
from utils.visualizations import style, empty_fig

st.set_page_config(page_title="Smart Energy Dashboard", page_icon="⚡", layout="wide", initial_sidebar_state="expanded")
st.markdown('''<style>
:root{--navy:#10243a;--teal:#0f766e;--mint:#d8f3ed}
.block-container{padding-top:1.5rem;padding-bottom:2rem}
[data-testid="stSidebar"]{background:#102a43}
[data-testid="stSidebar"] *{color:#f4f8fb}
.hero{padding:1.3rem 1.5rem;border-radius:18px;background:linear-gradient(120deg,#10243a,#0f766e);color:white;margin-bottom:1rem}
.hero h1{color:white;margin:0}.hero p{opacity:.9;margin:.35rem 0 0}
.kpi{border:1px solid #e4eaf0;border-radius:14px;padding:1rem;background:white;min-height:105px}
.kpi-label{font-size:.85rem;color:#617184}.kpi-value{font-size:1.8rem;font-weight:750;color:#10243a}.kpi-note{font-size:.78rem;color:#0f766e}
</style>''',unsafe_allow_html=True)

st.sidebar.markdown("# ⚡ Smart Energy")
st.sidebar.caption("Consumption • Load survey • Meter intelligence")
page=st.sidebar.radio("Navigation",["Home Dashboard","Consumption Analysis","Load Survey Analysis","Meter Analysis","Anomaly Detection","Data Explorer","Data Management"])
st.sidebar.divider(); st.sidebar.caption("Local CSV storage • demo dataset included")

def get_data(): return load_all()
def df_for(name): return get_data()[name][0]
def show_table(df, key=None):
    st.dataframe(df, use_container_width=True, hide_index=True, height=360)
def download_csv(df, filename, label="Download CSV"):
    st.download_button(label,df.to_csv(index=False).encode("utf-8"),file_name=filename,mime="text/csv")
def search_filter(df, key):
    q=st.text_input("Search across all columns",placeholder="Type a meter ID, region, date, status...",key=key)
    return filtered_frame(df,q),q

def metric(label,value,note="From current CSV data"):
    st.markdown(f'<div class="kpi"><div class="kpi-label">{label}</div><div class="kpi-value">{value}</div><div class="kpi-note">{note}</div></div>',unsafe_allow_html=True)

def date_filter(df, col):
    if not col: return df
    dates=pd.to_datetime(df[col],errors="coerce").dropna()
    if dates.empty: return df
    c1,c2=st.columns(2)
    start=c1.date_input("Start date",value=dates.min().date(),key=f"{col}_start")
    end=c2.date_input("End date",value=dates.max().date(),key=f"{col}_end")
    d=pd.to_datetime(df[col],errors="coerce")
    return df[(d.dt.date>=start)&(d.dt.date<=end)]

all_data=get_data()
cons=all_data["Consumption"][0]; survey=all_data["Load Survey"][0]; meters=all_data["Meters"][0]
if page=="Home Dashboard":
    st.markdown('<div class="hero"><h1>Smart Energy Consumption Analysis</h1><p>Monitor electricity usage, explore survey insights, check meter health and find unusual readings.</p></div>',unsafe_allow_html=True)
    st.info("Demo mode: included CSV files contain synthetic sample records so you can test every page. Replace them with your real data in Data Management.")
    if cons.empty:
        st.error("Consumption dataset is empty or missing. Open Data Management to upload a CSV.")
    else:
        num=numeric_columns(cons); ccol="consumption_kwh" if "consumption_kwh" in cons else (num[0] if num else None)
        total=float(cons[ccol].sum()) if ccol else 0; avg=float(cons[ccol].mean()) if ccol else 0
        m1,m2,m3,m4=st.columns(4)
        with m1: metric("Total Consumption",f"{total:,.1f} kWh")
        with m2: metric("Average Reading",f"{avg:,.2f} kWh")
        with m3: metric("Meters Tracked",f"{cons['meter_id'].nunique():,}" if 'meter_id' in cons else f"{len(meters):,}")
        with m4: metric("Potential Anomalies",f"{len(find_anomalies(cons,ccol)):,}" if ccol else "0")
        st.subheader("Consumption over time")
        dc=date_column(cons)
        if dc and ccol:
            temp=cons.copy(); temp[dc]=pd.to_datetime(temp[dc],errors="coerce"); temp=temp.dropna(subset=[dc])
            trend=(temp.assign(_plot_date=temp[dc].dt.date)
                   .groupby("_plot_date", as_index=False)[ccol].sum()
                   .rename(columns={"_plot_date": "Date", ccol: "Consumption (kWh)"}))
            st.plotly_chart(style(px.area(trend,x="Date",y="Consumption (kWh)",markers=True,color_discrete_sequence=["#0f766e"])),use_container_width=True)
        else: st.plotly_chart(empty_fig("Date or numeric consumption column not found"),use_container_width=True)
        c1,c2=st.columns(2)
        with c1:
            st.subheader("Consumption by region")
            if "region" in cons and ccol:
                group=cons.groupby("region",as_index=False)[ccol].sum(); st.plotly_chart(style(px.bar(group,x="region",y=ccol,color="region")),use_container_width=True)
            else: st.plotly_chart(empty_fig("Region column not found"),use_container_width=True)
        with c2:
            st.subheader("Meter status")
            if "status" in meters: st.plotly_chart(style(px.pie(meters,names="status",hole=.55)),use_container_width=True)
            else: st.plotly_chart(empty_fig("Meter status unavailable"),use_container_width=True)
        st.subheader("Latest consumption records"); show_table(cons.tail(10))
elif page=="Consumption Analysis":
    st.title("📈 Consumption Analysis"); st.caption("Filter readings, compare meters and download the selected records.")
    if cons.empty: st.warning("No consumption data. Upload a CSV in Data Management.")
    else:
        dc=date_column(cons); filtered=date_filter(cons,dc)
        numeric=numeric_columns(filtered); default="consumption_kwh" if "consumption_kwh" in numeric else (numeric[0] if numeric else None)
        if default:
            col=st.selectbox("Metric to analyze",numeric,index=numeric.index(default)); filtered=filtered.copy(); filtered[col]=pd.to_numeric(filtered[col],errors="coerce")
            c1,c2=st.columns(2)
            if "meter_id" in filtered:
                choices=["All meters"]+sorted(filtered.meter_id.dropna().astype(str).unique().tolist()); chosen=c1.selectbox("Meter",choices)
                if chosen!="All meters": filtered=filtered[filtered.meter_id.astype(str)==chosen]
            if "region" in filtered:
                regions=["All regions"]+sorted(filtered.region.dropna().astype(str).unique().tolist()); reg=c2.selectbox("Region",regions)
                if reg!="All regions": filtered=filtered[filtered.region.astype(str)==reg]
            a,b,c=st.columns(3)
            with a: metric("Total",f"{filtered[col].sum():,.2f}")
            with b: metric("Average",f"{filtered[col].mean():,.2f}")
            with c: metric("Maximum",f"{filtered[col].max():,.2f}")
            if dc and dc in filtered:
                tmp=filtered.copy()
                tmp[dc]=pd.to_datetime(tmp[dc],errors="coerce")
                tmp=tmp.dropna(subset=[dc])
                grp=(tmp.assign(_plot_date=tmp[dc].dt.date)
                       .groupby("_plot_date", as_index=False)[col].sum()
                       .rename(columns={"_plot_date": "Date"}))
                st.plotly_chart(style(px.line(grp,x="Date",y=col,markers=True)),use_container_width=True)
            if "meter_id" in filtered:
                grp=filtered.groupby("meter_id",as_index=False)[col].sum().sort_values(col,ascending=False)
                st.plotly_chart(style(px.bar(grp,x="meter_id",y=col,color=col,color_continuous_scale="Tealgrn")),use_container_width=True)
            st.subheader("Filtered records"); show_table(filtered); download_csv(filtered,"filtered_consumption.csv")
        else: st.warning("No numeric columns were found in this dataset.")
elif page=="Load Survey Analysis":
    st.title("🏠 Load Survey Analysis")
    if survey.empty: st.warning("No survey data. Upload a CSV in Data Management.")
    else:
        dc=date_column(survey); view=date_filter(survey,dc); view,q=search_filter(view,"survey_search")
        nums=numeric_columns(view); c1,c2=st.columns(2)
        with c1:
            if nums:
                col=st.selectbox("Numeric field",nums,key="survey_num"); st.plotly_chart(style(px.histogram(view,x=col,color_discrete_sequence=["#0f766e"])),use_container_width=True)
        with c2:
            cat=[x for x in view.columns if x not in nums and view[x].nunique(dropna=True)<=30]
            if cat:
                cc=st.selectbox("Category field",cat,key="survey_cat"); grp=view[cc].astype(str).value_counts().rename_axis(cc).reset_index(name="Records"); st.plotly_chart(style(px.bar(grp,x=cc,y="Records")),use_container_width=True)
        st.subheader(f"Survey records ({len(view):,})"); show_table(view); download_csv(view,"filtered_load_survey.csv")
elif page=="Meter Analysis":
    st.title("🔌 Meter Analysis")
    if meters.empty: st.warning("No meter data. Upload a CSV in Data Management.")
    else:
        view,q=search_filter(meters,"meter_search")
        c1,c2,c3=st.columns(3)
        with c1: metric("Meters",f"{len(view):,}")
        with c2: metric("Active",f"{(view['status'].astype(str).str.lower()=='active').sum():,}" if "status" in view else "N/A")
        with c3: metric("Regions",f"{view['region'].nunique():,}" if "region" in view else "N/A")
        if "status" in view: st.plotly_chart(style(px.pie(view,names="status",hole=.5)),use_container_width=True)
        show_table(view); download_csv(view,"filtered_meters.csv")
elif page=="Anomaly Detection":
    st.title("🚨 Anomaly Detection"); st.caption("Interquartile-range screening highlights unusually low or high numeric readings. Review before acting.")
    if cons.empty: st.warning("No consumption data. Upload a CSV in Data Management.")
    else:
        nums=numeric_columns(cons)
        if not nums: st.warning("No numeric columns are available.")
        else:
            default="consumption_kwh" if "consumption_kwh" in nums else nums[0]
            col=st.selectbox("Column to inspect",nums,index=nums.index(default)); factor=st.slider("Sensitivity (IQR multiplier)",0.5,3.0,1.5,0.25)
            anomalies=find_anomalies(cons,col,factor)
            a,b,c=st.columns(3)
            with a: metric("Rows scanned",f"{len(cons):,}")
            with b: metric("Flagged rows",f"{len(anomalies):,}")
            with c: metric("Flag rate",f"{len(anomalies)/max(len(cons),1)*100:.2f}%")
            if not anomalies.empty: st.warning("These are statistical flags, not confirmed faults."); show_table(anomalies); download_csv(anomalies,"anomaly_flags.csv")
            else: st.success("No rows were flagged with the selected sensitivity.")
elif page=="Data Explorer":
    st.title("🔎 Data Explorer"); name=st.selectbox("Choose dataset",list(DATASETS)); df,source=load_all()[name]
    st.caption(f"Source: {source} • {len(df):,} rows • {len(df.columns):,} columns")
    if df.empty: st.warning("This dataset is empty or missing. Use Data Management to upload a CSV.")
    else:
        view,q=search_filter(df,"explorer_search")
        c1,c2=st.columns(2)
        with c1: st.write("**Column types**"); st.dataframe(pd.DataFrame({'Column':df.columns,'Data type':[str(x) for x in df.dtypes]}),hide_index=True,use_container_width=True)
        with c2: st.write("**Summary statistics**"); st.dataframe(df.describe(include="all").transpose().fillna(""),use_container_width=True)
        st.write(f"**Search results: {len(view):,} rows**"); show_table(view); download_csv(view,f"{name.lower().replace(' ','_')}_export.csv")
elif page=="Data Management":
    st.title("🗂️ Data Management"); st.write("Upload a CSV to replace a dataset, append records, or download the current stored CSV. Changes are saved in the local `data/` folder.")
    st.info("The included data are synthetic demo records for testing. Upload your real CSVs here when available. Keep a backup before replacing files.")
    name=st.selectbox("Dataset to manage",list(DATASETS),key="manage_dataset"); current,source=load_all()[name]
    st.caption(f"Current source: {source} • {len(current):,} rows • {len(current.columns):,} columns")
    upload=st.file_uploader("Upload CSV file",type=["csv"],key=f"upload_{name}")
    mode=st.radio("Upload action",["Replace current dataset","Append rows to current dataset"],horizontal=True)
    if upload is not None:
        try:
            incoming=pd.read_csv(upload); st.write("**Preview uploaded data**"); show_table(incoming.head(20))
            if st.button("Save uploaded CSV",type="primary"):
                if mode.startswith("Append") and not current.empty:
                    # Preserve all columns; missing columns are filled with blank values.
                    incoming=pd.concat([current,incoming],ignore_index=True,sort=False)
                path=save_dataset(name,incoming); st.success(f"Saved {len(incoming):,} rows to {path}"); st.rerun()
        except Exception as e: st.error(f"Could not read this CSV: {e}")
    st.divider(); st.subheader("Current stored data")
    if current.empty: st.warning("No current rows are available.")
    else:
        st.dataframe(current.head(100),use_container_width=True,hide_index=True)
        download_csv(current,DATASETS[name][0],"Download current CSV")
        st.subheader("Add a record")
        with st.form(f"add_{name}"):
            values={}; cols=st.columns(2)
            for i,col in enumerate(current.columns):
                dtype=current[col].dtype
                with cols[i%2]:
                    if pd.api.types.is_numeric_dtype(dtype): values[col]=st.number_input(col,value=0.0,key=f"add_{name}_{col}")
                    else: values[col]=st.text_input(col,key=f"add_{name}_{col}")
            submitted=st.form_submit_button("Add record to CSV")
        if submitted:
            updated=pd.concat([current,pd.DataFrame([values])],ignore_index=True); path=save_dataset(name,updated); st.success(f"Record added and saved to {path}"); st.rerun()
        st.subheader("Delete a record")
        if len(current):
            idcol=next((c for c in ["meter_id","survey_id","date"] if c in current.columns),current.columns[0])
            options=[f"Row {i+1} — {current.iloc[i][idcol]}" for i in range(len(current))]
            selected=st.selectbox("Select record",options,key=f"delete_{name}")
            if st.button("Delete selected record",type="secondary"):
                idx=options.index(selected); updated=current.drop(current.index[idx]).reset_index(drop=True); save_dataset(name,updated); st.success("Record deleted from CSV."); st.rerun()
    st.caption("Storage location: smart_energy_dashboard/data/ • CSV files persist between app restarts.")

st.sidebar.divider(); st.sidebar.caption("Smart Energy Dashboard • Local prototype")
