import plotly.express as px
import plotly.graph_objects as go

def style(fig, title=None):
    fig.update_layout(title=title, template="plotly_white", margin=dict(l=12,r=12,t=55,b=12), font=dict(family="Arial",size=12), legend_title_text="")
    return fig

def empty_fig(message="No data available"):
    fig=go.Figure(); fig.add_annotation(text=message, x=.5,y=.5,showarrow=False); fig.update_xaxes(visible=False); fig.update_yaxes(visible=False); return style(fig)
