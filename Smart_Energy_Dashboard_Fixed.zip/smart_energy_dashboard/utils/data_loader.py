from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
DATASETS = {
    "Consumption": ("consumption_clean.csv", "consumption_clean.parquet"),
    "Load Survey": ("load_survey_clean.csv", "load_survey_clean.parquet"),
    "Meters": ("meters_clean.csv", "meters_clean.parquet"),
}

def load_dataset(name):
    csv_name, parquet_name = DATASETS[name]
    csv_path, parquet_path = DATA_DIR / csv_name, ROOT / parquet_name
    if csv_path.exists():
        try: return pd.read_csv(csv_path), "CSV"
        except Exception as exc: return pd.DataFrame(), f"Could not read CSV: {exc}"
    if parquet_path.exists():
        try: return pd.read_parquet(parquet_path), "Parquet"
        except Exception as exc: return pd.DataFrame(), f"Could not read Parquet: {exc}"
    return pd.DataFrame(), "Missing"

def load_all():
    return {name: load_dataset(name) for name in DATASETS}

def save_dataset(name, df):
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    path = DATA_DIR / DATASETS[name][0]
    df.to_csv(path, index=False)
    return path
