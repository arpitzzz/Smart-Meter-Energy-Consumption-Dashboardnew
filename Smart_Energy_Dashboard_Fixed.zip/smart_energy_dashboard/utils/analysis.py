import pandas as pd
import numpy as np

def numeric_columns(df): return list(df.select_dtypes(include="number").columns)
def date_column(df):
    for c in df.columns:
        if c.lower() in ("date", "timestamp", "datetime", "survey_date", "reading_date"):
            return c
    return None

def find_anomalies(df, column, factor=1.5):
    if column not in df or not pd.api.types.is_numeric_dtype(df[column]): return df.iloc[0:0].copy()
    s=pd.to_numeric(df[column], errors="coerce").dropna()
    if s.empty: return df.iloc[0:0].copy()
    q1,q3=s.quantile([.25,.75]); iqr=q3-q1
    if iqr == 0: return df.iloc[0:0].copy()
    return df[(pd.to_numeric(df[column],errors="coerce") < q1-factor*iqr) | (pd.to_numeric(df[column],errors="coerce") > q3+factor*iqr)]

def filtered_frame(df, search=""):
    if not search.strip(): return df
    mask=df.astype(str).apply(lambda col: col.str.contains(search.strip(), case=False, na=False)).any(axis=1)
    return df[mask]
